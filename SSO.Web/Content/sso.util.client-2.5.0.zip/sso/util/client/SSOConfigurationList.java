package sso.util.client;

public class SSOConfigurationList {

	public static String ssoBaseUrl = null;
	public static String ssoSecretKey = null;
	public static String ssoCookieKey = null;
	public static String ssoCookieTime = null;
	public static String messageBaseUrl = null;
	public static String fileBaseUrl = null;

	static {
		ssoBaseUrl = ApplicationProperties.getValue("sso.base.url");
		if (ssoBaseUrl == null) {
			ssoBaseUrl = ApplicationProperties.getValue("ssoBaseUrl");
		}
		ssoSecretKey = ApplicationProperties.getValue("sso.secret.key");
		if (ssoSecretKey == null) {
			ssoSecretKey = ApplicationProperties.getValue("ssoSecretKey");
		}
		ssoCookieKey = ApplicationProperties.getValue("sso.cookie.key");
		if (ssoCookieKey == null) {
			ssoCookieKey = ApplicationProperties.getValue("ssoCookieKey");
		}
		ssoCookieTime = ApplicationProperties.getValue("sso.cookie.time");
		if (ssoCookieTime == null) {
			ssoCookieTime = ApplicationProperties.getValue("ssoCookieTime");
		}
		messageBaseUrl = ApplicationProperties.getValue("message.base.url");
		if (messageBaseUrl == null) {
			messageBaseUrl = ApplicationProperties.getValue("messageBaseUrl");
		}
		fileBaseUrl = ApplicationProperties.getValue("file.base.url");
		if (fileBaseUrl == null) {
			fileBaseUrl = ApplicationProperties.getValue("fileBaseUrl");
		}
	}
}
