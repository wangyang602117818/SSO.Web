package sso.util.client.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class SearchData {
	private String database;
	private String table;
	private String key;
	private String id;
	private String title;
	private String description;
	private String extra;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date doc_time;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date create_time;
}
