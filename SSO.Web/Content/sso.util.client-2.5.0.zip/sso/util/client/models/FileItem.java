package sso.util.client.models;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class FileItem {
	private String id;
	private String from;
	private String fileId;
	private String fileName;
	private String machine;
	private String folder;
	private String length;
	private int width;
	private int height;
	private int download;
	private String fileType;
	private String contentType;
	private int duration;
	private String owner;
	private int state;
	private int percent;
	private int ProcessCount;
	private boolean delete;
	private boolean exception;
	private List<ConvertFile> thumbnails;
	private List<ConvertFile> videos;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date deleteTime;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
}
