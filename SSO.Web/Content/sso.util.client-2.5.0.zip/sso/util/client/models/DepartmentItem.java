package sso.util.client.models;

import java.util.List;

import lombok.Data;

@Data
public class DepartmentItem {
	private int id;
	private String code;
	private String name;
	private String description;
	private int order;
	private int layer;
	private String parentCode;
	private List<DepartmentItem> children;
}
