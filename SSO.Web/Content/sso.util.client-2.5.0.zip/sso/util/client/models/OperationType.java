package sso.util.client.models;

public enum OperationType {
	insert(0), delete(1), replace(2), update(3), drop(4), rename(5), dropDatabase(6), invalidate(7);

	private final int id;

	OperationType(int id) {
		this.id = id;
	}

	public int getValue() {
		return id;
	}
}
