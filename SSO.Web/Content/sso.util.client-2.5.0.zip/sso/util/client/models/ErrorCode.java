package sso.util.client.models;

public enum ErrorCode {
	success(0), redirect(1), authcode_is_null(101), app_not_exist(102), app_blocked(103), error_permission(104),
	invalid_params(105), params_valid_fault(106), owner_not_match(107), file_type_blocked(108), username_required(109),
	usercode_required(110), no_handler_available(111), api_not_available(112), url_not_available(113),
	old_password_error(114), record_not_exist(200), uri_not_found(201), usercode_exist(202), login_fault(203),
	task_not_completed(204), invalid_password(205), file_type_not_match(206), requests_has_been_exceeded(220),
	task_not_complete(300), record_exist(400), authorize_fault(401), invalid_token(402), token_expired(403),
	page_not_found(404), ssoUrl_not_config(600), ssoSecret_not_config(601), ssoCookieKey_not_config(602),
	ssoCookieTime_not_config(603), messageUrl_not_config(604), record_has_been_used(700), task_is_running(701),
	server_exception(-1000);

	private final int id;

	ErrorCode(int id) {
		this.id = id;
	}

	public int getValue() {
		return id;
	}
}
