package sso.util.client.models;

import java.io.InputStream;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UploadFileItem {
	private String fileName;
	private String contentType;
	private InputStream fileStream;
}
