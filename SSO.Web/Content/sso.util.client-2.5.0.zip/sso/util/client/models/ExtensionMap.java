package sso.util.client.models;

import java.util.List;

import lombok.Data;

@Data
public class ExtensionMap {
	private String type;
	private List<String> extensions;
}
