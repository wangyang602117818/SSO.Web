package sso.util.client.models;

import lombok.Data;

@Data
public class ResponseModel<T> {
	private int code;
	private String message;
	private T result;
	private long count;

	public ResponseModel(ErrorCode code, T result) {
		this(code, result, 0);
	}

	public ResponseModel(ErrorCode code, T result, long count) {
		this.code = code.getValue();
		this.message = code.toString();
		this.result = result;
		this.count = count;
	}

	public ResponseModel(int code, String message, T result) {
		this.code = code;
		this.message = message;
		this.result = result;
		this.count = 0;
	}

	public ResponseModel(int code, String message, T result, long count) {
		this.code = code;
		this.message = message;
		this.result = result;
		this.count = count;
	}
}
