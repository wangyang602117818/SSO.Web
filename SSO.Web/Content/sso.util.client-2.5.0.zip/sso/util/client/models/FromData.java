package sso.util.client.models;

import lombok.Data;

@Data
public class FromData {
	private String from;
	private int count;
}
