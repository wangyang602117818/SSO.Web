package sso.util.client.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class UserItem {
	private String id;
	private String userId;
	private String userName;
	private String companyCode;
	private String sex;
	private String mobile;
	private String companyName;
	private String departmentName;
	private String roleName;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
}
