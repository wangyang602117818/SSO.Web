package sso.util.client.models;

import lombok.Data;

@Data
public class LogModel {
	private String from;
	private String to;
	private String controller;
	private String action;
	private String route;
	private String queryString;
	private String content;
	private String response;
	private String userId;
	private String userName;
	private String userHost;
	private String userAgent;
	private long time;
	private int countPerMinute;
	private boolean exception;
}
