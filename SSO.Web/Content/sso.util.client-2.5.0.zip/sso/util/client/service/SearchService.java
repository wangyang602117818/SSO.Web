package sso.util.client.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;

import sso.util.client.HttpClientRequestHelper;
import sso.util.client.JsonSerializerHelper;
import sso.util.client.SSOConfigurationList;
import sso.util.client.StringExtention;
import sso.util.client.models.DataBaseType;
import sso.util.client.models.OperationType;
import sso.util.client.models.SearchData;
import sso.util.client.models.ServiceModel;
import sso.util.client.models.SuggestData;

public class SearchService {
	/// <summary>
	/// message center baseUrl
	/// </summary>
	public String baseUrl = "";
	public String Token;
	HttpClientRequestHelper requestHelper = new HttpClientRequestHelper();
	HashMap<String, String> headers = new HashMap<String, String>();

	public SearchService() {
		this.baseUrl = StringExtention.Trim(SSOConfigurationList.messageBaseUrl, "/");
	}

	public SearchService(String baseUrl) {
		this.baseUrl = StringExtention.Trim(baseUrl, "/");
	}

	public ServiceModel<String> InsertSearchData(DataBaseType database, String table, String key, String title,
			String description, LocalDateTime doc_time) throws Exception {
		return InsertSearchData(database, table, key, title, description, doc_time, "");
	}

	public ServiceModel<String> InsertSearchData(DataBaseType database, String table, String key, String title,
			String description, LocalDateTime doc_time, String extra) throws Exception {
		SearchModel data = new SearchModel();
		data.operationType = OperationType.insert;
		data.database = database;
		data.table = table;
		data.key = key;
		data.title = title;
		data.description = description;
		data.doc_time = doc_time;
		data.extra = extra;
		String result = requestHelper.Post(baseUrl + "/searchData/insert", data, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<String>>() {
		});
	}

	public ServiceModel<String> DeleteSearchData(DataBaseType database, String table, String key) throws Exception {
		SearchModel data = new SearchModel();
		data.operationType = OperationType.insert;
		data.database = database;
		data.table = table;
		data.key = key;
		String result = requestHelper.Post(baseUrl + "/searchData/insert", data, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<String>>() {
		});
	}

	public ServiceModel<List<SuggestData>> Suggest(String word) throws Exception {
		return Suggest(word, DataBaseType.none, "");
	}

	public ServiceModel<List<SuggestData>> Suggest(String word, DataBaseType database) throws Exception {
		return Suggest(word, database, "");
	}

	public ServiceModel<List<SuggestData>> Suggest(String word, DataBaseType database, String table) throws Exception {
		String url = baseUrl + "/searchdata/suggest?word=" + word;
		if (database != DataBaseType.none)
			url += "&database=" + database.toString();
		if (!StringExtention.IsNullOrEmpty(table))
			url += "&table=" + table.toString();
		String result = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<List<SuggestData>>>() {
		});
	}

	public ServiceModel<List<SearchData>> Search(String word) throws Exception {
		return Search(word, DataBaseType.none, "", false, 1, 10);
	}

	public ServiceModel<List<SearchData>> Search(String word, DataBaseType database, String table) throws Exception {
		return Search(word, database, table, false, 1, 10);
	}

	public ServiceModel<List<SearchData>> Search(String word, DataBaseType database, String table, Boolean highlight)
			throws Exception {
		return Search(word, database, table, highlight, 1, 10);
	}

	public ServiceModel<List<SearchData>> Search(String word, DataBaseType database, String table, Boolean highlight,
			int pageIndex, int pageSize) throws Exception {
		String url = baseUrl + "/searchdata/search?word=" + word + "&highlight=" + highlight + "&pageIndex=" + pageIndex
				+ "&pageSize=" + pageSize;
		if (database != DataBaseType.none)
			url += "&database=" + database.toString();
		if (!StringExtention.IsNullOrEmpty(table))
			url += "&table=" + table.toString();
		String result = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<List<SearchData>>>() {
		});
	}

	class SearchModel {
		public OperationType operationType;
		public DataBaseType database;
		public String table;
		public String key;
		public String title;
		public String description;
		public LocalDateTime doc_time;
		public String extra;
	}
}
