package sso.util.client.service;

import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;

import javax.servlet.http.HttpServletResponse;

import sso.util.client.ApplicationProperties;
import sso.util.client.HttpClientRequestHelper;
import sso.util.client.JsonSerializerHelper;
import sso.util.client.JwtManager;
import sso.util.client.SSOConfigurationList;
import sso.util.client.StringExtention;
import sso.util.client.models.DownloadFileItem;
import sso.util.client.models.ExtensionMap;
import sso.util.client.models.FileItem;
import sso.util.client.models.FileResponse;
import sso.util.client.models.FileType;
import sso.util.client.models.FromData;
import sso.util.client.models.ServiceModel;
import sso.util.client.models.UploadFileItem;

public class FileClientService {
	private HttpClientRequestHelper requestHelper = new HttpClientRequestHelper();
	public String RemoteUrl;
	public String Token;
	HashMap<String, String> headers = new HashMap<String, String>();
	JwtManager jwtManager = new JwtManager();

	public FileClientService(String token) {
		this(null, token);
	}

	public FileClientService(String remoteUrl, String token) {
		if (!StringExtention.IsNullOrEmpty(remoteUrl)) {
			RemoteUrl = StringExtention.Trim(remoteUrl, "/");
		} else {
			RemoteUrl = StringExtention.Trim(SSOConfigurationList.fileBaseUrl, "/");
		}
		Token = token;
		headers.put("Authorization", token);
	}

	public ServiceModel<FileResponse> Upload(String fileName, String contentType, InputStream stream,
			List<String> roles, List<String> users) throws Exception {
		ArrayList<UploadFileItem> files = new ArrayList<UploadFileItem>();
		UploadFileItem uploadFileItem = new UploadFileItem(fileName, contentType, stream);
		files.add(uploadFileItem);
		ServiceModel<List<FileResponse>> result = this.Uploads(files, roles, users);
		ServiceModel<FileResponse> responServiceModel = new ServiceModel<FileResponse>(result.getCode(),
				result.getMessage(), result.getResult().get(0), result.getCount());
		return responServiceModel;
	}

	public ServiceModel<List<FileResponse>> Uploads(List<UploadFileItem> files, List<String> roles, List<String> users)
			throws Exception {
		HashMap<String, String> param = new HashMap<String, String>();
		if (roles != null && !roles.isEmpty())
			param.put("roles", JsonSerializerHelper.Serialize(roles));
		if (users != null && !users.isEmpty())
			param.put("users", JsonSerializerHelper.Serialize(users));

		String result = requestHelper.PostFile(RemoteUrl + "/upload/file", files, param, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<List<FileResponse>>>() {
		});
	}

	public DownloadFileItem DownloadFile(String id, String filename) throws Exception {
		return DownloadFile(id, filename, "");
	}

	public void DownloadFile(HttpServletResponse response, String id, String filename) throws Exception {
		DownloadFileItem file = DownloadFile(id, filename);
		DownloadFile(response, file);
	}

	public void DownloadFilePreview(HttpServletResponse response, String id, String filename) throws Exception {
		DownloadFileItem file = DownloadFile(id, filename);
		PreviewFile(response, file);
	}

	public DownloadFileItem DownloadFile(String id, String filename, String flag) throws Exception {
		return requestHelper.GetFile(RemoteUrl + "/file/" + id + "/" + filename + "?mode=download&flag=" + flag,
				headers);
	}

	public void DownloadFile(HttpServletResponse response, String id, String filename, String flag) throws Exception {
		DownloadFileItem file = DownloadFile(id, filename, flag);
		DownloadFile(response, file);
	}

	public void DownloadFilePreview(HttpServletResponse response, String id, String filename, String flag)
			throws Exception {
		DownloadFileItem file = DownloadFile(id, filename, flag);
		PreviewFile(response, file);
	}

	public DownloadFileItem DownloadFileIcon(String id, String filename) throws Exception {
		return requestHelper.GetFile(RemoteUrl + "/file/GetFileIconWrapId/" + id + StringExtention.GetFileExt(filename),
				headers);
	}

	public ServiceModel<Integer> FileState(String id) throws Exception {
		String state = requestHelper.Get(RemoteUrl + "/data/FileState/" + id, headers);
		return JsonSerializerHelper.Deserialize(state, new TypeReference<ServiceModel<Integer>>() {
		});
	}

	public ServiceModel<List<FileItem>> GetFileList() throws Exception {
		return GetFileList(1, 10, "", "", FileType.all, null, null, null, false);
	}

	public ServiceModel<List<FileItem>> GetFileList(int pageIndex, int pageSize, String from, String filter,
			FileType fileType, LocalDateTime startTime, LocalDateTime endTime, HashMap<String, String> sorts,
			Boolean delete) throws Exception {
		String url = RemoteUrl + "/data/GetFiles?pageIndex=" + pageIndex + "&pageSize=" + pageSize;
		if (!StringExtention.IsNullOrEmpty(from))
			url += "&from=" + from;
		if (!StringExtention.IsNullOrEmpty(filter))
			url += "&filter=" + filter;
		if (fileType != null && fileType != FileType.all)
			url += "&fileType=" + fileType.toString();
		if (startTime != null)
			url += "&startTime=" + startTime.format(ApplicationProperties.dateTimeFormatter);
		if (endTime != null)
			url += "&endTime=" + endTime.format(ApplicationProperties.dateTimeFormatter);
		int index = 0;
		if (sorts != null) {
			for (String key : sorts.keySet()) {
				url += "&sorts[" + index + "].key=" + key;
				url += "&sorts[" + index + "].value=" + sorts.get(key);
				index++;
			}
		}
		url += "&delete=" + delete;
		String list = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(list, new TypeReference<ServiceModel<List<FileItem>>>() {
		});
	}

	public ServiceModel<FileItem> GetFileInfo(String id) throws Exception {
		String url = RemoteUrl + "/data/GetFileInfo/" + id;
		String item = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(item, new TypeReference<ServiceModel<FileItem>>() {
		});
	}

	public ServiceModel<List<FileItem>> GetFileInfos(List<String> ids) throws Exception {
		String url = RemoteUrl + "/data/GetFileInfos";
		ModelIds model = new ModelIds();
		model.ids = ids;
		String result = requestHelper.Post(url, model, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<List<FileItem>>>() {
		});
	}

	public ServiceModel<List<FromData>> GetFromList() throws Exception {
		String url = RemoteUrl + "/data/GetFromList";
		String list = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(list, new TypeReference<ServiceModel<List<FromData>>>() {
		});
	}

	public ServiceModel<List<ExtensionMap>> GetExtensionMap() throws Exception {
		String url = RemoteUrl + "/data/GetExtensionsMap";
		String list = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(list, new TypeReference<ServiceModel<List<ExtensionMap>>>() {
		});
	}

	public ServiceModel<String> RemoveFile(String fileId) throws Exception {
		String url = RemoteUrl + "/data/Remove/" + fileId;
		String result = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<String>>() {
		});
	}

	public ServiceModel<String> RemoveFiles(List<String> fileIds) throws Exception {
		String url = RemoteUrl + "/data/Removes";
		ModelIds model = new ModelIds();
		model.ids = fileIds;
		String result = requestHelper.Post(url, model, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<String>>() {
		});
	}

	public ServiceModel<String> RestoreFile(String fileId) throws Exception {
		String url = RemoteUrl + "/data/Restore/" + fileId;
		String result = requestHelper.Get(url, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<String>>() {
		});
	}

	public ServiceModel<String> RestoreFiles(List<String> fileIds) throws Exception {
		String url = RemoteUrl + "/data/Restores";
		ModelIds model = new ModelIds();
		model.ids = fileIds;
		String result = requestHelper.Post(url, model, headers);
		return JsonSerializerHelper.Deserialize(result, new TypeReference<ServiceModel<String>>() {
		});
	}

	public DownloadFileItem M3u8MultiStream(String id, String filename) throws Exception {
		return this.M3u8MultiStream(id, filename, 0);
	}

	public void DownloadM3u8MultiStream(HttpServletResponse response, String id, String filename) throws Exception {
		DownloadM3u8MultiStream(response, id, filename, 0);
	}

	public DownloadFileItem M3u8MultiStream(String id, String filename, int time) throws Exception {
		if (time > 0)
			headers.put("time", String.valueOf(time));
		return requestHelper.GetFile(RemoteUrl + "/file/" + id + "/" + filename, headers);
	}

	public void DownloadM3u8MultiStream(HttpServletResponse response, String id, String filename, int time)
			throws Exception {
		DownloadFileItem file = this.M3u8MultiStream(id, filename, time);
		DownloadFile(response, file);
	}

	public DownloadFileItem M3u8(String id, String filename) throws Exception {
		return M3u8(id, filename, 0);
	}

	public void DownloadM3u8(HttpServletResponse response, String id, String filename) throws Exception {
		DownloadM3u8(response, id, filename, 0);
	}

	public DownloadFileItem M3u8(String id, String filename, int time) throws Exception {
		if (time > 0)
			headers.put("time", String.valueOf(time));
		return requestHelper.GetFile(RemoteUrl + "/file/" + id + "/" + filename, headers);
	}

	public void DownloadM3u8(HttpServletResponse response, String id, String filename, int time) throws Exception {
		DownloadFileItem file = this.M3u8(id, filename, time);
		DownloadFile(response, file);
	}

	public DownloadFileItem Ts(String id, String filename) throws Exception {
		return requestHelper.GetFile(RemoteUrl + "/file/" + id + "/" + filename, headers);
	}

	public void DownloadTs(HttpServletResponse response, String id, String filename) throws Exception {
		DownloadFileItem file = this.Ts(id, filename);
		DownloadFile(response, file);
	}

	private void DownloadFile(HttpServletResponse response, DownloadFileItem file) throws Exception {
		OutputStream outputStream = response.getOutputStream();
		response.setHeader("Content-Disposition", "attachment; filename=" + file.getFileName());
		response.setContentType(file.getContentType());
		byte[] buffer = new byte[1024];
		int len;
		while ((len = file.getFileStream().read(buffer)) > 0) {
			outputStream.write(buffer, 0, len);
		}
		file.getFileStream().close();
	}

	private void PreviewFile(HttpServletResponse response, DownloadFileItem file) throws Exception {
		OutputStream outputStream = response.getOutputStream();
		response.setHeader("Content-Disposition", "inline; filename=" + file.getFileName());
		response.setContentType(file.getContentType());
		byte[] buffer = new byte[1024];
		int len;
		while ((len = file.getFileStream().read(buffer)) > 0) {
			outputStream.write(buffer, 0, len);
		}
		file.getFileStream().close();
	}

	class ModelIds {
		public List<String> ids;
	}
}
