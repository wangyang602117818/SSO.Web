package sso.util.client.models;

public class SuggestData {
	public String id;
	public String text;
}
