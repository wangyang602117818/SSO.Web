package sso.util.client.models;

import lombok.Data;

@Data
public class SuggestData {
	private String id;
	private String text;
}
