package sso.util.client.models;

import java.io.InputStream;

public class UploadFileItem {
	public String FileName;
	public String ContentType;
	public InputStream FileStream;
}
