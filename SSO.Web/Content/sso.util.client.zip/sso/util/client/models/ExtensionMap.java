package sso.util.client.models;

import java.util.List;

public class ExtensionMap {
	public String Type;
	public List<String> Extensions;
}
