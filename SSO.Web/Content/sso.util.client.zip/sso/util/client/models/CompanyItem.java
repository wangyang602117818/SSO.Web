package sso.util.client.models;

public class CompanyItem {
	public String Code;
	public String Name;
	public int Order;
}
