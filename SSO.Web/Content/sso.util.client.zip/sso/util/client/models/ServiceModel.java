package sso.util.client.models;

public class ServiceModel<T> {
	public int code;
	public String message;
	public T result;
	public int count;
}
