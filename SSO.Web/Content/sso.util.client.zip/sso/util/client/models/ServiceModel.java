package sso.util.client.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServiceModel<T> {
	private int code;
	private String message;
	private T result;
	private long count;
}
