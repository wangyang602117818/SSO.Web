package sso.util.client.models;

import java.util.Map;

import lombok.Data;

@Data
public class UserData {
	private String from = null;
	private String userId = null;
	private String userName = null;
	private String lang = null;
	private Map<String, String> extra;
}
