package sso.util.client.models;

import java.io.InputStream;

import lombok.Data;

@Data
public class DownloadFileItem {
	private String fileName;
	private String contentType;
	private long contentLength;
	private InputStream fileStream;
}
