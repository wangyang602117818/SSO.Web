package sso.util.client.models;

import java.io.InputStream;

public class DownloadFileItem {
	public String FileName;
	public String ContentType;
	public long ContentLength;
	public InputStream FileStream;
}
