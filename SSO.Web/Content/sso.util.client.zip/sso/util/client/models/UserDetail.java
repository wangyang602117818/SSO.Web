package sso.util.client.models;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class UserDetail {
	private String id;
	private String userId;
	private String userName;
	private String companyCode;
	private String companyName;
	private String mobile;
	private String email;
	private String idCard;
	private String sex;
	private boolean isModified;
	private List<String> departmentCode;
	private List<String> departmentName;
	private List<String> role;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date lastLoginTime;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;
}
