package sso.util.client.models;

import java.util.List;

public class DepartmentItem {
	public String value;
	public String title;
	public int Order;
	public List<DepartmentItem> children;
}
