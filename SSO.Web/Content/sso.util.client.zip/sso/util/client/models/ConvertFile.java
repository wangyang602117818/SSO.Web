package sso.util.client.models;

import java.util.Date;

import lombok.Data;

@Data
public class ConvertFile {
	private String id;
	public String flag;
	public Date completedTime;
}
