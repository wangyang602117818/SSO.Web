package sso.util.client.models;

import java.time.LocalDateTime;

public class ConvertFile {
	public String Id;
	public String Flag;
	public LocalDateTime CompletedTime;
}
