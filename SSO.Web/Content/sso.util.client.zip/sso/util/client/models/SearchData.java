package sso.util.client.models;

import java.time.LocalDateTime;

public class SearchData {
	public String database;
	public String table;
	public String key;
	public String id;
	public String title;
	public String description;
	public String extra;
	public LocalDateTime doc_time;
	public LocalDateTime create_time;
}
