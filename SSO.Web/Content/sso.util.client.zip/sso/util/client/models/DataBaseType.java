package sso.util.client.models;

public enum DataBaseType {
	none(0), sqlserver(1), mongodb(2);

	private final int id;

	DataBaseType(int id) {
		this.id = id;
	}

	public int getValue() {
		return id;
	}
}
