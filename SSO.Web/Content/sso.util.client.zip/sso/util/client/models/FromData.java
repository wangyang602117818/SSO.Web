package sso.util.client.models;

public class FromData {
	public String From;
	public int Count;
}
