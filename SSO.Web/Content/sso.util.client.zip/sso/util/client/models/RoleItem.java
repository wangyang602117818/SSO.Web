package sso.util.client.models;

import java.util.Date;

public class RoleItem {
	public String Id;
	public String Name;
	public String Description;
	public Date CreateTime;
	public Date UpdateTime;
}
