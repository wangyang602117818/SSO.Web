package sso.util.client.models;

public class FileResponse {
	public String FileId;
	public String FilePath;
	public String FileName;
	public long FileSize;
	public String Message;
}
