package sso.util.client.models;

import lombok.Data;

@Data
public class FileResponse {
	private String fileId;
	private String filePath;
	private String fileName;
	private long fileSize;
	private String message;
}
